package Cartão;

import javax.swing.JOptionPane;

public class Natal extends CartaoWeb {
    
    public void Natal(String destinario){
        
        
    }

    @Override
    public void retornarMensagem(String remetente, String destinatario) {
        String mensagem = String.format("%s ,\n Feliz Natal! \n"
                + "Muitas felicidades, que esse dia seja cheio de luz e paz no seu coração, \n att %s.", destinatario, remetente);
        JOptionPane.showMessageDialog(null, mensagem);
    }
    
}
