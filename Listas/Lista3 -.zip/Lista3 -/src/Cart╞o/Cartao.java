package Cartão;

import java.util.Random;
import javax.swing.JOptionPane;


public class Cartao {

    public static void main(String[] args) {
        
        CartaoWeb [] cartoes = new CartaoWeb[3];
        cartoes[0] = new DiaDosNamorados();
        cartoes[1] = new Natal();
        cartoes[2] = new Aniversario();
        
        Random seleciona = new Random();
        CartaoWeb cartaoescolhido;
        
        for(int i = 0; i<3; i++){
            
            cartaoescolhido = cartoes[i];
            cartaoescolhido.retornarMensagem(JOptionPane.showInputDialog("Informe o Remetente: "), JOptionPane.showInputDialog("Informe o Destinatario: "));
        }
    }
    
}
