package Cartão;

import javax.swing.JOptionPane;

public class DiaDosNamorados extends CartaoWeb {

    
    
    public void DiaDosNamorados(String destinatario){
        
    }

    @Override
    public void retornarMensagem(String remetente, String destinatario) {
        String mensagem = String.format("%s ,\n Feliz dia dos namorados! \n"
                + "Que venha muitos anos ao seu lado! te amo, att \n %s", destinatario, remetente);
        JOptionPane.showMessageDialog(null, mensagem);
    }
    
}
