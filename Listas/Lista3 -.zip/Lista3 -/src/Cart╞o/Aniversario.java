package Cartão;

import javax.swing.JOptionPane;

public class Aniversario extends CartaoWeb {

    public void Aniversario(String destinatario){
        
    }
    
    @Override
    public void retornarMensagem(String remetente, String destinatario) {
        String mensagem = String.format("%s ,\n Feliz Aniversário! \n"
                + " Muitas felicidades, que essa data seja de alegria e paz\n att %s", destinatario, remetente);
        JOptionPane.showMessageDialog(null, mensagem);
    }
    
}
