package Cartão;

public abstract class CartaoWeb {
    protected String destinatario;

    

 public abstract void retornarMensagem(String remetente, String destinario);

    
 
}