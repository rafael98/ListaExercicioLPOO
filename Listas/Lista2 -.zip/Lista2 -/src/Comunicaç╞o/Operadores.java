package Comunicação;

public class Operadores {
     
    private String nome;
    private int valor;
    private String pacote;
    private String contrato;

    public Operadores() {
    }

    public Operadores(String nome, int valor, String pacote, String contrato) {
        this.nome = nome;
        this.valor = valor;
        this.pacote = pacote;
        this.contrato = contrato;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    public String getPacote() {
        return pacote;
    }

    public void setPacote(String pacote) {
        this.pacote = pacote;
    }

    public String getContrato() {
        return contrato;
    }

    public void setContrato(String contrato) {
        this.contrato = contrato;
    }
    
    
    
}
