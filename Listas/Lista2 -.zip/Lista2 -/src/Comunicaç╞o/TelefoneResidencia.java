package Comunicação;


public class TelefoneResidencia {
   
    private int comprimentoCabo;
    private int tamanho;
    private String cor;

    public TelefoneResidencia() {
    }

    public int getComprimentoCabo() {
        return comprimentoCabo;
    }

    public void setComprimentoCabo(int comprimentoCabo) {
        this.comprimentoCabo = comprimentoCabo;
    }

    public int getTamanho() {
        return tamanho;
    }

    public void setTamanho(int tamanho) {
        this.tamanho = tamanho;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }
    
  
 
    
}
