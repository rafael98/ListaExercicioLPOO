
package Comunicação;

public class Computador {
  private String AcessoInternet;
  private int Armazenamento;
  private int velocidade;

    public Computador() {
    }

    public Computador(String AcessoInternet, int Armazenamento, int velocidade) {
        this.AcessoInternet = AcessoInternet;
        this.Armazenamento = Armazenamento;
        this.velocidade = velocidade;
    }

    
    
    public String getAcessoInternet() {
        return AcessoInternet;
    }

    public void setAcessoInternet(String AcessoInternet) {
        this.AcessoInternet = AcessoInternet;
    }

    public int getArmazenamento() {
        return Armazenamento;
    }

    public void setArmazenamento(int Armazenamento) {
        this.Armazenamento = Armazenamento;
    }

    public int getVelocidade() {
        return velocidade;
    }

    public void setVelocidade(int velocidade) {
        this.velocidade = velocidade;
    }
  
  
    
}
