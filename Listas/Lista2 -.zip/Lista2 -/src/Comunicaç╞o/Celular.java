package Comunicação;

public class Celular extends Operadores{
    
    private String cor;
    private int bateria;
    private int frequencia;
    private String radio;
    
    

    public Celular() {
    }

    public Celular(String cor, 
                   int bateria, 
                   String radio,
                   String pacote,
                   String contrato) {
        
   
        
        
        this.cor = cor;
        this.bateria = bateria;
        this.radio = radio;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public int getBateria() {
        return bateria;
    }

    public void setBateria(int bateria) {
        this.bateria = bateria;
    }

    public int getFrequencia() {
        return frequencia;
    }

    public void setFrequencia(int frequencia) {
        this.frequencia = frequencia;
    }

    public String getRadio() {
        return radio;
    }

    public void setRadio(String radio) {
        this.radio = radio;
    }
    
    
    
    
}
