package Conta;

import javax.swing.JOptionPane;

public class Vendedor extends Empregado {
    
    private double valorVendas;
    private int porcentagem;
    private double comissao;

    public Vendedor() {
    }

    public Vendedor(double valorVendas, 
                    int porcentagem, 
                    double salario, 
                    String nome, 
                    int idade, 
                    double altura, 
                    String sexo) {
        
        super(salario, nome, idade, altura, sexo);
        this.valorVendas = valorVendas;
        this.porcentagem = porcentagem;
    }

    

    public double getValorVendas() {
        return valorVendas;
    }

    public void setValorVendas(double valorVendas) {
        this.valorVendas = valorVendas;
    }

    public double getComissao() {
        return comissao;
    }

    public void setComissao(double comissao) {
        this.comissao = comissao;
    }

    public int getPorcentagem() {
        return porcentagem;
    }

    public void setPorcentagem(int porcentagem) {
        this.porcentagem = porcentagem;
    }
    
    @Override
    public void obterLucros() {
        setComissao(((getValorVendas()*getPorcentagem())/100)+getSalario()); 
        JOptionPane.showMessageDialog(null,"Lucros do Vendedor: "+getComissao());
    }
    
}
