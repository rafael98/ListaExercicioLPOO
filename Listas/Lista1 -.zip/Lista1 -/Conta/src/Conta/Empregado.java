/**/
package Conta;

import javax.swing.JOptionPane;
public class Empregado extends Pessoa {
    
    private double salario;
    

    public Empregado() {
    }

    public Empregado(double salario, 
                    String nome, 
                    int idade,
                    double altura, 
                    String sexo) {
        super(nome, idade, altura, sexo);
        this.salario = salario;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }
    
    public void obterLucros(){
      
        JOptionPane.showMessageDialog(null,"Lucro do Empregado: "+getSalario());
        
    }

    
}
