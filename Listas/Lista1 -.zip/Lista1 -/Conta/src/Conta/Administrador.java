package Conta;

import javax.swing.JOptionPane;

public class Administrador extends Empregado {
    
    private double ajudasDeCusto;

    public Administrador() {
    }

    public Administrador(double ajudasDeCusto,
                         double salario,
                         String nome, 
                         int idade, 
                         double altura, 
                         String sexo) {
        super(salario, 
              nome,
              idade, 
              altura, 
              sexo);
        this.ajudasDeCusto = ajudasDeCusto;
    }

    public double getAjudasDeCusto() {
        return ajudasDeCusto;
    }

    public void setAjudasDeCusto(double AD) {
        this.ajudasDeCusto = AD;
    }

    @Override
    public void obterLucros() {
        setSalario(getSalario()+getAjudasDeCusto());
        JOptionPane.showMessageDialog(null,"Lucro do Administrador: "+getSalario());
    }
    
    
    
    
    
            
    
}
