package Conta;

import javax.swing.JOptionPane;

public class VendedorTeste {

    public static void main(String[] args) {

        Vendedor v = new Vendedor();
        
        v.setNome(JOptionPane.showInputDialog(null,"informe o nome"));
        
        v.setIdate(Integer.parseInt(JOptionPane.showInputDialog(null,"informe a idade")));
        
        v.setSalario(Double.parseDouble(JOptionPane.showInputDialog(null,"informe o salario")));
        
        v.setValorVendas(Double.parseDouble(JOptionPane.showInputDialog(null,"informe o valor de vendas")));
        
        v.setPorcentagem(Integer.parseInt(JOptionPane.showInputDialog(null,"informe a porcentagem da comissão")));
        
        v.setSexo(JOptionPane.showInputDialog(null,"infome o sexo"));
        
        v.setAltura(Double.parseDouble(JOptionPane.showInputDialog(null,"informe a altura")));
        
        
        JOptionPane.showMessageDialog(null,"DADOS DO EMPREGADO"+"\n"+"Nome: "+v.getNome()+"\n"+"Idade: "+v.getIdade()+"\n"+"Sexo: "+v.getSexo()+"\n"+"Altura: "+v.getAltura());
        v.obterLucros();
    }
    
}
