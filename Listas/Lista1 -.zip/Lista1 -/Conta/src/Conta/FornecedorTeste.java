/*
 */
package Conta;

import javax.swing.JOptionPane;

public class FornecedorTeste {

    public static void main(String[] args) {
        
        Fornecedor f = new Fornecedor();
        
        f.setNome(JOptionPane.showInputDialog(null,"informe o nome"));
        
        f.setCreditoMaximo(Double.parseDouble(JOptionPane.showInputDialog(null,"informe o crédito maximo")));
        
        f.setValorEmDivida(Double.parseDouble(JOptionPane.showInputDialog(null,"informe o valor da divida")));
        
        f.setIdate(Integer.parseInt(JOptionPane.showInputDialog(null,"informe a idade")));
        
        f.setSexo(JOptionPane.showInputDialog(null,"informe o sexo"));
        
        f.setAltura(Double.parseDouble(JOptionPane.showInputDialog(null,"informe a altura")));
        
        JOptionPane.showMessageDialog(null,"DADOS DA PESSOA CADASTRADOS NO FORNECEDOR"+"\n"+"Nome: "+f.getNome()+
        "\n"+"Credito: "+f.getCreditoMaximo()+"\n"+"Divida: "+f.getValorEmDivida()+
        "\n"+"Idade: "+f.getIdade()+"\n"+"Sexo: "+f.getSexo()+"\n"+"Altura: "+f.getAltura());
        
        f.obterSaldo();
        
        
        
    }
    
}
