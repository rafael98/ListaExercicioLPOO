/**/
package Conta;

import javax.swing.JOptionPane;

public class AdministradorTeste {

    public static void main(String[] args) {
 
        Administrador a = new Administrador();
        
        a.setNome(JOptionPane.showInputDialog(null,"informe o nome"));
        
        a.setIdate(Integer.parseInt(JOptionPane.showInputDialog(null,"informe a idade")));
        
        a.setSalario(Double.parseDouble(JOptionPane.showInputDialog(null,"informe seu salario")));
        
        a.setAjudasDeCusto(Double.parseDouble(JOptionPane.showInputDialog(null,"informe o valor da ajuda de custo")));
        
        a.setSexo(JOptionPane.showInputDialog(null,"informe o sexo"));
        
        a.setAltura(Double.parseDouble(JOptionPane.showInputDialog(null,"informe a altura")));
        
        
        JOptionPane.showMessageDialog(null,"DADOS DO EMPREGADO"+"\n"+"Nome: "+a.getNome()+"\n"+"Idade: "+a.getIdade()+"\n"+"Sexo: "+a.getSexo()+"\n"+"Altura: "+a.getAltura());
        a.obterLucros();
    }
    
}
