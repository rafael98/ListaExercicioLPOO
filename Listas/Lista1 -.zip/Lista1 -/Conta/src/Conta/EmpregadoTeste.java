package Conta;
import javax.swing.JOptionPane;

public class EmpregadoTeste {

    public static void main(String[] args) {
        
        Empregado e = new Empregado();
        
        e.setNome(JOptionPane.showInputDialog(null,"informe o nome"));
        
        e.setIdate(Integer.parseInt(JOptionPane.showInputDialog(null,"informe a idade")));
        
        e.setSalario(Double.parseDouble(JOptionPane.showInputDialog(null,"informe o salario")));
        
        e.setSexo(JOptionPane.showInputDialog(null,"informe o sexo"));
        
        e.setAltura(Double.parseDouble(JOptionPane.showInputDialog(null,"informe a altura")));
        
        
        
        JOptionPane.showMessageDialog(null,"DADOS DO EMPREGADO"+"\n"+"Nome: "+e.getNome()+"\n"+"Idade: "+e.getIdade()+"\n"+"Sexo: "+e.getSexo()+"\n"+"Altura: "+e.getAltura());
        e.obterLucros();
    }
    
}
