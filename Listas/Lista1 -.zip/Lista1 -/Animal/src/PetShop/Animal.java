package PetShop;

public class Animal {
    private String tipo;
    private String cor;

      public String getTipo() {
      return tipo;
      }

      public void setTipo(String t) {
      this.tipo = t;
      }

          public String getCor() {
          return cor;
          }

          public void setCor(String c) {
          this.cor = c;
          }

             public Animal() {
             }

             @Override
             public String toString() {
             return "Animal{" + "tipo=" + tipo + ", cor=" + cor + '}';
             }
    
    
}
