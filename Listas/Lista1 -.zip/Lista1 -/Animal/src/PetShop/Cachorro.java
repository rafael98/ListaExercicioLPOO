package PetShop;

public class Cachorro extends Animal{
    private String nome;
    private String raca;

    public Cachorro() {
    }

       public String getNome() {
       return nome;
       }

       public void setNome(String n) {
       this.nome = n;
       }

          public String getRaca() {
          return raca;
          }

          public void setRaca(String r) {
          this.raca = r;
          }

            @Override
            public String toString() {
            return "Cachorro{" + "nome=" + nome + ", raca=" + raca + '}';
            }
    
    
}
