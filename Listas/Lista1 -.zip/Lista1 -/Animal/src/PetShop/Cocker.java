package PetShop;

import javax.swing.JOptionPane;

public class Cocker extends Cachorro{
    private boolean tosa;

    public void setTosa(boolean tosa) {
        this.tosa = tosa;
    }
    
    public void precisaTosa(){
        int opc = JOptionPane.showConfirmDialog(null,"Precisa de tosa?:",     
          "Escolha um",JOptionPane.YES_NO_OPTION);
        
        if(opc==0){
            tosa = true;
        }else{
            tosa=false;
        }
    if(tosa==true){
        JOptionPane.showMessageDialog(null, "O Cachorro precisa de tosa!");
        
    }else if(tosa==false){
        
        JOptionPane.showMessageDialog(null, "O Cachorro não precisa de tosa!");

    }
}
}
