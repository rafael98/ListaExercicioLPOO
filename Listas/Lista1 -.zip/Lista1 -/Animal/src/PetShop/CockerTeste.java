package PetShop;

import javax.swing.JOptionPane;


public class CockerTeste {

    public static void main(String[] args) {
        Cocker c1 = new Cocker();
        
        c1.setCor(JOptionPane.showInputDialog("Infome a cor do cachorro:"));
        
        c1.setNome(JOptionPane.showInputDialog("Qual nome do cachorro?"));
        
        c1.setRaca(JOptionPane.showInputDialog("Qual raça é o cachorro?"));
        
        c1.setTipo(JOptionPane.showInputDialog("Qual é o tipo do cachorro?"));
        
        c1.precisaTosa();
        
    }
    
}
