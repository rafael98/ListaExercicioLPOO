/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import Controller.*;
import Model.*;
import java.util.*;


public class Principal {
    
    public static void main(String args[]) {   
        Scanner x = new Scanner (System.in);
        int opcao;
        
      ArrayList <Pessoa> pessoas = new ArrayList();
      ArrayList <Automovel> automovel = new ArrayList();
        
        do{
            System.out.println("1 - Cadastrar Funcionário ou Cliente \n2 - Cadastrar Carro ou Caminhão \n3 - Criar Aluguel \n4 - Sair");
            
        opcao = x.nextInt();
            switch (opcao){
        case 1:
             System.out.println("Digite 1 para Funcionario e 2 para Cliente: ");
        int F = x.nextInt();
        if (F == 1){
            Funcionario func = new Funcionario();
            System.out.println("Insira o Nome:");
            func.setNome(x.next());
            System.out.println("Insira o CPF: ");
            func.setCpf(x.nextInt());
            System.out.println("Insira a Data de Nascimento");
            func.setDatanasc(x.nextInt());
            System.out.println("Digite o ID do funcionario");
            func.setIdFuncionario(x.nextInt());
            pessoas.add(func);
            break;
        }
            if (F == 2) {
            Cliente cli = new Cliente(); 
            System.out.println("Insira o Nome:");
            cli.setNome(x.next());
            System.out.println("Insira o CPF: ");
            cli.setCpf(x.nextInt());
            System.out.println("Insira a Data de Nascimento");
            cli.setDatanasc(x.nextInt());
            System.out.println("Digite o ID do funcionario");
            cli.setIdCliente(x.nextInt());
                pessoas.add(cli);
                break;
                    }
           break;
        case 2:
           System.out.println("Digite 1 para Carro e 2 para Caminhão: ");
           int C = x.nextInt();
        if (C == 1){
            System.out.println("Digite 1 para Carro e 2 para Caminhão: ");
            Carro car = new Carro();
            System.out.println("Insira o Chassi:");
            car.setChassi(x.nextInt());
            System.out.println("Insira o Modelo: ");
            car.setModelo(x.next());
            System.out.println("Insira a Placa");
            car.setPlaca(x.next());
            System.out.println("Digite a Marca do Veiculo");
            car.setMarca(x.next());
            automovel.add(car);
            break;
        }
        
        if (C == 2 ){    
            Caminhao cam = new Caminhao();
            System.out.println("Insira o Chassi:");
            cam.setChassi(x.nextInt());
            System.out.println("Insira o Modelo: ");
            cam.setModelo(x.next());
            System.out.println("Insira a Placa");
            cam.setPlaca(x.next());
            System.out.println("Digite a Marca do Veiculo");
            cam.setMarca(x.next());
            automovel.add(cam);
            break;

        }
        
            break;
            
        case 3:
            ArrayList <AluguelDeAutomovel> aluguel = new ArrayList();
             System.out.println( Arrays.toString( pessoas.toArray()));
             System.out.println( Arrays.toString( automovel.toArray()));
            
        GerarAluguel gerar = new GerarAluguel();
        
        gerar.setCliente((Cliente)pessoas.get(x.nextInt()));
        gerar.setAutomovel((Carro)automovel.get(x.nextInt()));
        aluguel.add((AluguelDeAutomovel) gerar.tipoDeAluguel());
        System.out.println( Arrays.toString( aluguel.toArray()));
        
            break;
        }           
        }
        while(opcao != 4);
        
    }
    
} 