package Model;

public abstract class AluguelDeAutomovel {
    
    private Pessoa nome;
    private Pessoa cpf;

    public void TempoDeAluguel(){};

    public Pessoa getNome() {
        return nome;
    }

    public void setNome(Pessoa nome) {
        this.nome = nome;
    }

    public Pessoa getCpf() {
        return cpf;
    }

    public void setCpf(Pessoa cpf) {
        this.cpf = cpf;
    }
    
    
    
    
    
}
