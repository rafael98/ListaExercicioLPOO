/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author aluno
 */
public class Automovel extends AluguelDeAutomovel {

    private String marca;
    String modelo;
    private int chassi;
    private String placa;
    

    public Automovel() {
    }

    public Automovel(String marca, String modelo, int chassi, String placa) {

        this.marca = marca;
        this.modelo = modelo;
        this.chassi = chassi;
        this.placa = placa;
        
    }

    public String getMarca() {
        return marca;
    }

    /**
     * @param marca the marca to set
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }

    /**
     * @return the modelo
     */
    public String getModelo() {
        return modelo;
    }

    /**
     * @param modelo the modelo to set
     */
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    /**
     * @return the chassi
     */
    public int getChassi() {
        return chassi;
    }

    /**
     * @param chassi the chassi to set
     */
    public void setChassi(int chassi) {
        this.chassi = chassi;
    }

    /**
     * @return the placa
     */
    public String getPlaca() {
        return placa;
    }

    /**
     * @param placa the placa to set
     */
    public void setPlaca(String placa) {
        this.placa = placa;
    }

    @Override
    public void TempoDeAluguel() {

    }

}
