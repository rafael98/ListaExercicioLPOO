/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author aluno
 */
public class Cliente extends Pessoa{
    
    private int idCliente;

    public Cliente() {
    }
    
    public Cliente(String nome,int cpf,int datanasc){
        super(nome,cpf,datanasc);
        
    };

    @Override
    public String toString(){
        return "Nome: " + this.getNome() + "Cpf: " + getCpf();
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }
    
    
    
}
